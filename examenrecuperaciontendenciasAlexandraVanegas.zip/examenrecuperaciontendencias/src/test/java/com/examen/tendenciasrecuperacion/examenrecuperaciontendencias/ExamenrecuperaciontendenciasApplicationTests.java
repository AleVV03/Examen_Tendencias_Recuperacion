package com.examen.tendenciasrecuperacion.examenrecuperaciontendencias;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamenrecuperaciontendenciasApplicationTests {

	@Test
	void contextLoads() {
	}

}
