package com.examen.tendenciasrecuperacion.examenrecuperaciontendencias.services;

import com.examen.tendenciasrecuperacion.examenrecuperaciontendencias.models.Empleado;


public interface EmpleadoService extends GenericService<Empleado, Long> {


}
